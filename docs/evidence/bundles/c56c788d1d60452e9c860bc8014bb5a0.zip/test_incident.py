from pathlib import Path
from skylark.wind.artifacts import replay_directory

def test_recorded_incident():
    result = replay_directory(Path(__file__).parent)
    assert result['matches_recorded'], result
